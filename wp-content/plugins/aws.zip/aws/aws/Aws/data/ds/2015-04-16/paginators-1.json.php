<?php
// This file was auto-generated from sdk-root/src/data/ds/2015-04-16/paginators-1.json
return [ 'pagination' => [ 'DescribeDomainControllers' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'Limit', ], ],];
